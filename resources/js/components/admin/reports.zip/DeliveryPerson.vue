<template>
    <div class="container">
        <!-- /.row -->
        <div class="row">
            <h2>Delivery Person</h2>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Delivery Person List</h3>

                        <div class="card-tools">
                            <!-- <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right"
                                    placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div> -->
                            <button type="button" @click="newForm" class="btn btn-success" data-toggle="modal"
                                data-target="#deliveryPersonNew"> <i class="fa fa-deliveryPerson-plus"></i> Add New</button>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">

                        <table class="table table-hover" >
                            <tr>
                                <th>Sr. No</th>
                                <th>Name</th>
                                <th>On / Off</th>
                                <th>Cash Limit</th>
                                <!-- <th>Total Cash</th> -->
                                <th>On Duty</th>
                                <th>Mobile</th>
                                <th>Email</th>
                                <th>Working Type</th>
                                <th>Commodity Delivers</th>
                                <!-- <th>Last Activity</th> -->
                                <th>Actions</th>
                            </tr>

                            <tr v-for="(deliveryPerson, index) in deliveryPersons" :key="deliveryPerson.id">
                                <td>{{(1+index)}}</td>
                                <td>{{ deliveryPerson.name  }}</td>
                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" :id="'onOff'+deliveryPerson.id"  :checked="deliveryPerson.is_active" @change="changeActiveStatus(deliveryPerson)">
                                        <label class="custom-control-label" :for="'onOff'+deliveryPerson.id" ></label>
                                    </div>
                                </td>
                                 <td>{{deliveryPerson.cash_limit}}</td>
                                <td> <span class="badge" :class="{ 'badge-success': deliveryPerson.available, 'badge-danger' : !deliveryPerson.available }" > {{deliveryPerson.available ? 'Yes' : 'No'}} </span></td>
                                <td>{{deliveryPerson.mobile}}</td>
                                <td>{{deliveryPerson.email}}</td>
                                <td>{{deliveryPerson.working_type == 1 ? 'Full time' : 'Part time'}}</td>
                                <td >

                                    <span  v-for="com in deliveryPerson.commodity" :key="com.id" class="badge badge-warning">
                                        <span v-if="com.commodity != null">
                                            {{ com.commodity.name }}
                                        </span>
                                    </span>
                                </td>
                                <!-- <td>{{deliveryPerson.last_activity != null ? deliveryPerson.last_activity : 'NA'}}</td> -->
                                <td>
                                    <button @click="editForm(deliveryPerson)"  data-toggle="modal" data-target="#deliveryPersonNew" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button @click="deleteDeliveryPerson(deliveryPerson.id)" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <router-link :to="getDeliveryPersonWalletLink(deliveryPerson)" class="btn btn-success btn-sm" >
                                        <i class="fa fa-rupee-sign"></i>
                                    </router-link>
                                    <router-link :to="getDeliveryPersonCommoditiesLink(deliveryPerson)" class="btn btn-success btn-sm" >
                                        <i class="fa fa-cubes"></i>
                                    </router-link>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <!-- Card body / -->
                    <div v-if="isLoading" class="overlay dark">
                        <i class="fas fa-3x fa-spin fa-sync-alt"></i>
                    </div>
                </div><!-- /.row -->


                <!-- Modal -->
                <div class="modal fade" id="deliveryPersonNew" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-deliveryPerson"></i>
                                    {{ editMode ? 'Edit' : 'Add'}} DeliveryPerson</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form @submit.prevent="editMode ? updateDeliveryPerson() : createDeliveryPerson()">
                                <div class="modal-body">
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" v-model="form.name"
                                                placeholder="DeliveryPerson Name"
                                                :class="{ 'is-invalid': form.errors.has('name') }">
                                            <has-error :form="form" field="name"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Mobile</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" v-model="form.mobile" :class="{ 'is-invalid': form.errors.has('mobile') }">
                                            <has-error :form="form" field="mobile"></has-error>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Email</label>
                                        <div class="col-sm-10">
                                            <input type="email" class="form-control" v-model="form.email" :class="{ 'is-invalid': form.errors.has('email') }">
                                            <has-error :form="form" field="email"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Service Area</label>
                                        <div class="col-sm-10">
                                            <select v-if="serviceAreas.length > 0" class="form-control" v-model="form.service_area_id"  :class="{ 'is-invalid': form.errors.has('service_area_id') }" >
                                                <option :value="null" disabled>Select Area</option>
                                                <option v-for="area in serviceAreas" :key="area.id" :value="area.id">{{ area.name }}</option>
                                            </select>
                                            <has-error :form="form" field="service_area_id"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label" :class="{ 'is-invalid': form.errors.has('working_type') }">Working Type : </label>
                                        <div class="col-sm-10">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <input type="radio" name="working_type" :value="1" v-model="form.working_type" id="distance_type"> <label for="distance_type">Full Time</label>
                                                </div>
                                                <div class="col-sm-6">
                                                    <input type="radio" name="working_type" :value="0" v-model="form.working_type" id="amount_type"> <label for="amount_type">Part Time</label>
                                                </div>
                                            </div>
                                            <has-error :form="form" field="working_type"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Driving License No</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" v-model="form.driving_license_no"  :class="{ 'is-invalid': form.errors.has('driving_license_no') }">
                                            <has-error :form="form" field="driving_license_no"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Aadhar No</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" v-model="form.aadhar_no"   :class="{ 'is-invalid': form.errors.has('aadhar_no') }">
                                            <has-error :form="form" field="aadhar_no"></has-error>
                                        </div>
                                    </div>
                                     
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Slab time</label>
                                        <div class="col-sm-10">
                                            <input type="text" minlength="2" maxlength="3" class="form-control without_ampm"  v-model="form.slab" placeholder= "Enter Time in min(i.e 20 ,30,40) format." :class="{ 'is-invalid': form.errors.has('slab') }">
                                            <has-error :form="form" field="slab"></has-error>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Cash Limit</label>
                                        <div class="col-sm-10">
                                            <input type="text" minlength="2" maxlength="5" class="form-control without_ampm"  v-model="form.cash_limit" placeholder= "Enter Cash Limit" :class="{ 'is-invalid': form.errors.has('cash_limit') }">
                                            <has-error :form="form" field="cash_limit"></has-error>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Bank Name</label>
                                        <div class="col-sm-10">
                                            <input type="text"  class="form-control bank"  v-model="form.bank" placeholder= "Enter Bank Name" :class="{ 'is-invalid': form.errors.has('bank') }">
                                            <has-error :form="form" field="bank"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">IFSC</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control without_ampm"  v-model="form.ifsc" placeholder= "Enter IFSC Code" :class="{ 'is-invalid': form.errors.has('ifsc') }">
                                            <has-error :form="form" field="ifsc"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Account Number</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control without_ampm"  v-model="form.acount_no" placeholder= "Enter Account Number" :class="{ 'is-invalid': form.errors.has('acount_no') }">
                                            <has-error :form="form" field="acount_no"></has-error>
                                        </div>
                                    </div>
                                    <div v-if="!editMode">

                                        <div class="row">
                                            <div class="col-sm-3">
                                                <label for="">
                                                    Select Commodity Type
                                                </label>
                                            </div>
                                            <div class="col-sm-6">
                                                <select required type="text" class="form-control" v-model="currentRule"
                                                placeholder="Coupon Name"
                                                :class="{ 'is-invalid': form.errors.has('commodity_type_id') }">
                                                    <option :value="null" disabled>Select Commodity type</option>
                                                    <option v-for="(mp, index) in commodities" :value="{commodity_type_id : mp.id , index : index} " :key="mp.id" :selected="mp.id == form.commodity_type_id">{{ mp.name}}</option>
                                                </select>
                                            </div>

                                            <div class="col-sm-3">
                                                <button type="button" class="btn btn-primary" @click="addRule">Add Rule</button>
                                            </div>
                                        </div>
                                        
                                       
                                        

                                        <div class="row">
                                            <div class="col-12">
                                                <table class="table table-responsive table-bordered col-12">
                                                    <thead>
                                                        <th>Sr. No.</th>
                                                        <th>Commodity Type</th>
                                                        <th>Action</th>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(ct, index) of form.commodities" :key="index">
                                                            <td>{{ (1+index)}}</td>
                                                            <td>
                                                                <label type="number" class="form-control"  :class="{ 'is-invalid': form.errors.has('commodities.'+index+'.commodity_type_id') }" >{{ commodities[ct.index].name }}</label>
                                                                <has-error :form="form" :field="'commodities.'+index+'.commodity_type_id'"></has-error>
                                                            </td>
                                                            <td>
                                                                <button class="btn btn-danger" @click="deleteRuleFromList(index)" type="button">
                                                                    <i class="fa fa-trash"></i>
                                                                </button>

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { moment } from 'moment';
    export default {
        data() {
            return {
                form : new Form({
                    id:null,
                    name:null,
                    mobile: null,
                    email: null,
                    service_area_id: null,
                    driving_license_no: null,
                    aadhar_no: null,
                    is_active: true,
                    working_type: 1,
                    slab:null,
                    acount_no:null,
                    ifsc:null,
                    cash_limit:null,
                    bank:null,
                    commodities: []
                }),
                deliveryPersons: [],
                currentRule: {
                    commodity_type_id: null,
                    index : null,
                },
                editMode: false,
                serviceAreas: [],
                commodities: [],
                isLoading: false
            }
        },
        methods :{
            createDeliveryPerson(){
                this.$Progress.start();

                this.form.post('api/delivery_person').then( ()=>{
                    Fire.$emit('LoadDeliveryPerson');
                    $('#deliveryPersonNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'DeliveryPerson Created successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{

                    this.$Progress.fail();
                });

                // this.loadDeliveryPersonList();
            },
            updateDeliveryPerson(){
                this.$Progress.start();
                this.form.put('api/delivery_person/' + this.form.id).then( ()=>{
                    Fire.$emit('LoadDeliveryPerson');
                    $('#deliveryPersonNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: this.form.name +' Updated successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{
                    this.$Progress.fail();
                });
            },
            loadDeliveryPersonList() {
                this.isLoading = true;
                axios.get("api/delivery_person").then( ({ data }) => {
                    this.deliveryPersons = data;
                    this.isLoading = false;
                });
            },
            deleteDeliveryPerson(id){
                // sweet alert modal
                swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        // send delete request
                        console.log(result)
                    if(result.value){
                        this.form.delete('/api/delivery_person/'+id).then(() => {
                            swal.fire(
                            'Deleted!',
                            'DeliveryPerson has been deleted.',
                            'success'
                            );
                            Fire.$emit('LoadDeliveryPerson');
                        }).catch(()=>{
                            swal.fire(
                            'Failed!',
                            `DeliveryPerson can't  be deleted.`,
                            'danger'
                            )
                        })
                    }
                })
            },
            newForm(){
                this.form.reset();
                this.editMode = false;
            },
            editForm(data){
                this.form.reset();
                this.form.fill(data);
                this.editMode = true;
            },
            fileSelected(e){
                console.log('file slected', e);
                if(e.target.files.length > 0 ){
                    let file = e.target.files[0];
                    let reader= new FileReader();
                    reader.onloadend = () => {
                        console.log('RESULT converted base 64');
                        this.form.image=  reader.result;
                    }
                    reader.readAsDataURL(file);
                }

            },
            changeActiveStatus(deliveryPerson){
                this.editForm(deliveryPerson);
                this.form.is_active = !this.form.is_active ;
                this.updateDeliveryPerson();
            },
            getImageUrl(deliveryPerson){
                return deliveryPerson.image == '' ? 'https://static.thenounproject.com/png/340719-200.png' : '/uploads/images/deliveryPerson/' + deliveryPerson.image;
            },
            loadServiceAreaList() {
                axios.get("api/service_area").then( ({ data }) => (this.serviceAreas = data) );
            },
            loadCommodityList() {
                axios.get("/api/commodity_type").then( ({ data }) => {
                    this.commodities = data;
                }).catch( err => console.log(err));
            },
            getDeliveryPersonWalletLink(deliveryPerson){
                return  `/delivery_wallet/${deliveryPerson.id}` ;
            },
            getDeliveryPersonCommoditiesLink(deliveryPerson){
                return  `/delivery_person/${deliveryPerson.id}/commodity` ;
            },
            addRule(){
                if(this.ruleExists(this.currentRule)){
                    swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Rule already present !',
                    });
                    return;
                }

                let rule = {...this.currentRule };
                this.form.commodities.push(rule);
            },
            ruleExists(currentRule){
                let rules = this.form.commodities;
                for(let x in rules){
                    if(rules[x].commodity_type_id == currentRule.commodity_type_id ){
                        return true;
                    }
                }
                return false;
            },
            deleteRuleFromList(index){
                this.form.commodities.splice(index,1);
            }
        },
        mounted() {
            console.log('Component mounted.')
        },
        created(){
            this.loadDeliveryPersonList();
            this.loadServiceAreaList();
            this.loadCommodityList();
            Fire.$on('LoadDeliveryPerson', () => this.loadDeliveryPersonList() );
        }


    }
</script>

<style scoped>
img{
    max-width : 5vh;
    max-height : 5vh
}
</style>
