<template>
    <div class="container">
        <!-- /.row -->
        <div class="row">
            <h2>Customer</h2>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Customer List</h3>

                        <div class="card-tools">
                            <!-- <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right"
                                    placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div> -->
                            <!-- <button type="button" @click="newForm" class="btn btn-success" data-toggle="modal"
                                data-target="#customerNew"> <i class="fa fa-customer-plus"></i> Add New</button> -->
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <!-- <table class="table table-hover">
                            <tr>
                                <th>Sr. No.</th>
                                <th>Name</th>
                                <th>On / Off</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>

                            <tr v-for="(customer, index) in customers" :key="customer.id">
                                <td>{{(1+index)}}</td>
                                <td>{{ customer.name | upText }}</td>
                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" :id="'onOff'+customer.id"  :checked="customer.is_active" @change="changeActiveStatus(customer)">
                                        <label class="custom-control-label" :for="'onOff'+customer.id" ></label>
                                    </div>
                                </td>
                                <td> <img :src="getImageUrl(customer)" alt="" class="img img-responsive" ></td>
                                <td>
                                    <button @click="editForm(customer)"  data-toggle="modal" data-target="#customerNew" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button @click="deleteCustomer(customer.id)" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>

                                    <router-link :to="getSlabLink(customer)" class="btn btn-warning btn-sm" @click="deleteRuleFromList(index)">

                                        <i class="fa fa-motorcycle"></i>
                                    </router-link>
                                </td>
                            </tr>

                        </table> -->
                        <data-table
                            :classes = "tableClasses"
                            url="/api/customer"
                            :columns="columns"

                            :per-page="perPage">
                        </data-table>
                    </div>
                </div><!-- /.row -->



            </div>
        </div>
    </div>
</template>

<script>
    import CImage from '../common/CImage.vue';
    import { moment } from 'moment';
    export default {
        components:{
            CImage
        },
        data() {
            return {
                perPage: ['10', '25', '50', '100', '250', '500'],
                columns: [
                    // {
                    //     label: 'ID',
                    //     name: 'id',
                    //     filterable: true,
                    // },
                    {
                        label: 'Name',
                        name: 'name',
                        filterable: true,
                    },
                    {
                        label: 'Mobile',
                        name: 'mobile',
                        filterable: true,
                    },
                    {
                        label: 'Email',
                        name: 'email',
                        filterable: true,
                    },
                    {
                        label: 'Gender',
                        name: 'gender',
                        filterable: true,
                    },
                ],
                tableClasses:{
                    "table-container": {
                        "table-responsive": true,
                    },
                    "table": {
                        "table": true,
                        "table-striped": true,
                        "table-dark": false,
                    },
                },
                customers: {},
                commodities: [],
                editMode: false,
                currentRule:{
                    limit_start:null,
                    limit_end:null,
                    charges:null,
                }
            }
        },
        methods :{
            loadCustomerList() {
                axios.get("api/customer").then( ({ data }) => (this.customers = data) );
            },
        },
        mounted() {
            console.log('Component mounted.')
        },
        created(){
            this.loadCustomerList();
            Fire.$on('LoadCustomer', () => this.loadCustomerList() );
        }


    }
</script>

<style scoped>
img{
    max-width : 5vh;
    max-height : 5vh
}
</style>
