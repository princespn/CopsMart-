<template>
    <div class="container">
        <!-- /.row -->
        <div class="row">
            <h2>Category-1</h2>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Category-1 List</h3>

                        <div class="card-tools">
                            <!-- <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right"
                                    placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div> -->
                            <button type="button" @click="newForm" class="btn btn-success" data-toggle="modal"
                                data-target="#categoryNew"> <i class="fa fa-category-plus"></i> Add New</button>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <tr>
                                <th>Sr. No.</th>
                                <th>Name</th>
                                <th>Total Categories-2</th>
                                <th>On / Off</th>
                                <th>Image</th>
                                <th>Actions</th>
                            </tr>
                            <!-- <tr>
                                <td>183</td>
                                <td>John Doe</td>
                                <td>11-7-2014</td>
                                <td><span class="tag tag-success">Approved</span></td>
                                <td>
                                    <a href="" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr> -->

                            <tr v-for="(category, index) in categories" :key="category.id">
                                <td>{{(1+index)}}</td>
                                <td>{{ category.name | upText }}</td>
                                <td><router-link :to="getCatLink(category)" class="btn btn-primary btn-sm">{{ category.count}}</router-link></td>
                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" :id="'onOff'+category.id"  :checked="category.is_active" @change="changeActiveStatus(category)">
                                        <label class="custom-control-label" :for="'onOff'+category.id" ></label>
                                    </div>
                                </td>
                                <td> <img :src="getImageUrl(category)" alt="" class="img img-responsive" ></td>
                                <td>
                                    <button @click="editForm(category)"  data-toggle="modal" data-target="#categoryNew" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button @click="deleteCategory(category.id)" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>

                                    <router-link :to="getSlabLink(category)" class="btn btn-warning btn-sm" @click="deleteRuleFromList(index)">

                                        <i class="fa fa-motorcycle"></i>
                                    </router-link>
                                </td>
                            </tr>

                        </table>
                    </div>
                </div><!-- /.row -->


                <!-- Modal -->
                <div class="modal fade" id="categoryNew" tabindex="-1" role="dialog"
                    aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                    <div class="modal-dialog modal-xl" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-category"></i>
                                    {{ editMode ? 'Edit' : 'Add'}} Super-Category</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form @submit.prevent="editMode ? updateCategory() : createCategory()">
                                <div class="modal-body">
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Name</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" v-model="form.name"
                                                placeholder="Category Name"
                                                :class="{ 'is-invalid': form.errors.has('name') }">
                                            <has-error :form="form" field="name"></has-error>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Image</label>
                                        <div class="col-sm-10">
                                            <input type="file" class="form-control" @change="fileSelected"
                                                id="staticEmail" :class="{ 'is-invalid': form.errors.has('image') }">
                                            <has-error :form="form" field="image"></has-error>
                                        </div>
                                    </div>
                                    <!-- <div class="form-group row">
                                        <label for="staticEmail" class="col-sm-2 col-form-label">Commodity Type</label>
                                        <div class="col-sm-10">
                                            <select required type="text" class="form-control" v-model="form.commodity_type_id"
                                                placeholder="Coupon Name"
                                                :class="{ 'is-invalid': form.errors.has('commodity_type_id') }">
                                                <option :value="null" disabled>Select Commodity type</option>
                                                <option v-for="mp in commodities" :value="mp.id" :key="mp.id">{{ mp.name}}</option>
                                            </select>
                                            <has-error :form="form" field="commodity_type_id"></has-error>
                                        </div>
                                    </div> -->
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Customer Discount</label>
                                        <div class="col-sm-10">
                                            <input type="number" min="0" max="100" step="0.01" v-model="form.discount_percentage" class="form-control"
                                                 :class="{ 'is-invalid': form.errors.has('discount_percentage') }">
                                            <has-error :form="form" field="discount_percentage"></has-error>
                                        </div>
                                    </div>
                                    <!--<div class="form-group row">
                                        <label class="col-sm-2 col-form-label">Marketing Commission</label>
                                        <div class="col-sm-10">
                                            <input type="number" min="0" max="100" step="0.01" v-model="form.marketing_commission_percentage" class="form-control"
                                                 :class="{ 'is-invalid': form.errors.has('marketing_commission_percentage') }">
                                            <has-error :form="form" field="marketing_commission_percentage"></has-error>
                                        </div>
                                    </div>-->
                                    <div class="form-group row">
                                        <label class="col-sm-2 col-form-label" :class="{ 'is-invalid': form.errors.has('delivery_calculation_type') }">Delivery Calculation : </label>
                                        <div class="col-sm-10">
                                            <div class="row">
                                                <!--<div class="col-sm-6">
                                                    <input type="radio" name="delivery_type" :value="1" v-model="form.delivery_calculation_type" id="distance_type"> <label for="distance_type">Distance</label>
                                                </div>-->
                                                <div class="col-sm-6">
                                                    <input type="radio" name="delivery_type" :value="0" v-model="form.delivery_calculation_type" id="amount_type"> <label for="amount_type">Amount</label>
                                                </div>
                                            </div>
                                            <has-error :form="form" field="delivery_calculation_type"></has-error>
                                        </div>
                                    </div>

                                    <div v-if="!editMode">

                                        <div class="row">
                                            <div class="col-sm-3">
                                                <input type="number" min="0" step=".1" :placeholder="form.delivery_calculation_type == 1 ? 'Start Limit in Km' : 'Start Limit amount in Rs'" v-model="currentRule.limit_start" class="form-control">
                                            </div>
                                            <div class="col-sm-3">
                                                <input type="number" min="0" step=".1" :placeholder="form.delivery_calculation_type == 1 ? 'End Limit in Km' : 'End Limit amount in Rs'"  v-model="currentRule.limit_end" class="form-control">
                                            </div>
                                            <div class="col-sm-3">
                                                <input type="number" min="0" placeholder="Delivery charge"  v-model="currentRule.charges" class="form-control">
                                            </div>
                                            <div class="col-sm-3">
                                                <button type="button" class="btn btn-primary" @click="addRule">Add Rule</button>
                                            </div>
                                        </div>

                                        <div class="col-xs-12">&nbsp;</div>
                                        <div class="form-row">
                                            <div class="form-group col-md-12">
                                             <div class="table-responsive">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <th class="col-xs-1">Sr. No.</th>
                                                        <th class="col-xs-3"> {{ form.delivery_calculation_type == 1 ? 'Distance' : 'Amount'}} limit start</th>
                                                        <th class="col-xs-3"> {{ form.delivery_calculation_type == 1 ? 'Distance' : 'Amount'}} limit end</th>
                                                        <th class="col-xs-3">Delivery Charge</th>
                                                        <th class="col-xs-2">Action</th>
                                                    </thead>
                                                    <tbody>
                                                        <tr v-for="(item, index) of form.delivery_rules" :key="index">
                                                            <td>{{ (1+index)}}</td>
                                                            <td>
                                                                <label class="form-control" :class="{ 'is-invalid': form.errors.has('delivery_rules.'+index+'.limit_start')   }"  > {{ item.limit_start }}</label>
                                                                <has-error :form="form" :field="'delivery_rules.'+index+'.limit_start'"></has-error>
                                                                <!-- <has-error :form="form" :field="'delivery_rules.'+index+'.vendor_id'"></has-error> -->
                                                            </td>
                                                            <td>
                                                                <label type="number" class="form-control"  :class="{ 'is-invalid': form.errors.has('delivery_rules.'+index+'.limit_end') }">{{ item.limit_end }}</label>
                                                                <has-error :form="form" :field="'delivery_rules.'+index+'.limit_end'" ></has-error>
                                                                </td>
                                                            <td>
                                                                <label type="number" class="form-control"  :class="{ 'is-invalid': form.errors.has('delivery_rules.'+index+'.charges') }" >{{ item.charges }}</label>
                                                                <has-error :form="form" :field="'delivery_rules.'+index+'.charges'"></has-error>
                                                            </td>
                                                            <td>
                                                                <button class="btn btn-danger" @click="deleteRuleFromList(index)" type="button">
                                                                    <i class="fa fa-trash"></i>
                                                                </button>

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                          </div>
                                        </div>
                                    </div>
                                     <div class="form-row" v-if="!editMode">
                                      <div class="form-group col-md-12">
                                        <div class="table-responsive">  
                                          <table class="table table-bordered" id="app" >
                                                <thead>
                                                    <tr>
                                                      <th class="col-xs-5">Category Name <span class="text-danger"></span></th>
                                                      <th class="col-xs-1">
                                                          <div>
                                                              <button title="Add row" type="button" @click="addRow" class="btn btn-success btn-sm"><b>Add Category</b></button>
                                                          </div>
                                                      </th>
                                                    </tr>
                                                </thead> 
                                                <tbody>
                                                <tr v-for="(input, index) in inputs"> 
                                                    <td>
                                                      <input type="text" name="category_name1[]" class="form-control category" placeholder="Category Name">
                                                    </td>
                                                    <td>
                                                        <button title="Delete row" type="button" @click="deleteRow(index)" class="btn btn-danger btn-sm"><b><i class="fa fa-trash"></i></b></button>
                                                    </td>
                                                </tr>
                                               </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Save </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { moment } from 'moment';
    export default {
        data() {
            return {
                form : new Form({
                    id:'',
                    name:'',
                    image: '',
                    is_active: true,
                    marketing_commission_percentage: null,
                    discount_percentage: null,
                    delivery_calculation_type: 0,
                    delivery_rules:[],
                    category_name:[]
                    
                }),
                categories: {},
                multipartForm : new FormData,
                commodities: [],
                inputs: [],
                editMode: false,
                currentRule:{
                    limit_start:null,
                    limit_end:null,
                    charges:null,
                }
            }
        },
        methods :{
            createCategory(){
                this.multipartForm = new FormData;
                this.$Progress.start();
                var category_name = [];
                $(".category").each(function(){ category_name.push($(this).val())});
                this.form.category_name=category_name;

                this.form.post('api/category').then( ()=>{
                    Fire.$emit('LoadCategory');
                    $('#categoryNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'Category Created successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{

                    this.$Progress.fail();
                });

                // this.loadCategoryList();
            },
            updateCategory(){
                this.$Progress.start();
                this.form.put('api/category/' + this.form.id).then( ()=>{
                    Fire.$emit('LoadCategory');
                    $('#categoryNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: this.form.name +' Updated successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{
                    this.$Progress.fail();
                });
            },
            loadCategoryList() {
                axios.get("api/category_all").then( ({ data }) => (this.categories = data) );
            },
            deleteCategory(id){
                // sweet alert modal
                swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        // send delete request
                        console.log(result)
                    if(result.value){
                        this.form.delete('/api/category/'+id).then(() => {
                            swal.fire(
                            'Deleted!',
                            'Category has been deleted.',
                            'success'
                            );
                            Fire.$emit('LoadCategory');
                        }).catch(()=>{
                            swal.fire(
                            'Failed!',
                            `Category can't  be deleted.`,
                            'danger'
                            )
                        })
                    }
                })
            },
            newForm(){
                this.form.reset();
                this.form.discount_percentage=0;
                this.editMode = false;
            },
            editForm(data){
                this.form.reset();
                this.form.fill(data);
                this.form.image = null;
                this.editMode = true;
            },
            fileSelected(e){
                console.log('file slected', e);
                if(e.target.files.length > 0 ){
                    let file = e.target.files[0];
                    let reader= new FileReader();
                    reader.onloadend = () => {
                        // console.log('RESULT converted base 64');
                        this.form.image=  reader.result;
                    }
                    reader.readAsDataURL(file);
                }

            },
            changeActiveStatus(category){
                this.editForm(category);
                this.form.is_active = !this.form.is_active ;
                this.updateCategory();
            },
            getImageUrl(category){
                return category.image == '' ? 'https://static.thenounproject.com/png/340719-200.png' : '/uploads/images/category/' + category.image;
            },
            loadCommodityList() {
                axios.get("api/commodity_type").then( ({ data }) => {
                    this.commodities = data;
                }).catch( err => console.log(err));
            },
            addRule(){
                if(this.ruleExists(this.currentRule)){
                    swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Rule already present !',
                    });
                    return;
                }
                if(this.emptyRule(this.currentRule)){
                    swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'Enter Rule Details Properly!',
                    });
                    return;
                }
                let rule = {...this.currentRule };
                this.form.delivery_rules.push(rule);
            },
            addRow() {
              this.inputs.push({
                one: '',
                two: ''
              })
            },
            deleteRow(index) {
              this.form.category_name.splice(index,1);
              this.inputs.splice(index,1);
            },
            ruleExists(currentRule){
                let rules = this.form.delivery_rules;
                for(let x in rules){
                    // this.form.delivery_rules[x] =
                    if(rules[x].limit_start >= currentRule.limit_start && rules[x].limit_end <= currentRule.limit_end ){
                        return true;
                    }
                }
                return false;
            },
            emptyRule(currentRule){
                if( (currentRule.limit_start == null || currentRule.limit_end == "")  &&  (currentRule.limit_end == null || currentRule.limit_end == "")  &&  (currentRule.charges == null || currentRule.charges == "") )
                    return true;
            },
            deleteRuleFromList(index){
                this.form.delivery_rules.splice(index,1);
            },
            getSlabLink(category){
                return `/category/${category.id}/slab`;
            },
            getCatLink(category){
                return `/category/${category.id}/cat`;
            }
        },
        mounted() {
            console.log('Component mounted.')
        },
        created(){
            this.loadCategoryList();
            Fire.$on('LoadCategory', () => this.loadCategoryList() );
        }
    }
</script>

<style scoped>
img{
    max-width : 5vh;
    max-height : 5vh
}
</style>
