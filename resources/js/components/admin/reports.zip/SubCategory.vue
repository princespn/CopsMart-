<template>
    <div class="container">
        <!-- /.row -->
        <div class="row">
            <h2>Category-3</h2>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Category-3 List</h3>

                        <div class="card-tools">
                            <!-- <div class="input-group input-group-sm" style="width: 150px;">
                                <input type="text" name="table_search" class="form-control float-right"
                                    placeholder="Search">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                                </div>
                            </div> -->
                            <button type="button" @click="newForm" class="btn btn-success" data-toggle="modal" data-target="#subCategoryNew"> <i class="fa fa-subCategory-plus"></i> Add New</button>
                        </div>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Name</th>
                                    <th>On / Off</th>
                                    <th>Category-1</th>
                                    <th>Category</th>
                                    <th>Image</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <!-- <tr>
                                <td>183</td>
                                <td>John Doe</td>
                                <td>11-7-2014</td>
                                <td><span class="tag tag-success">Approved</span></td>
                                <td>
                                    <a href="" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    <a href="" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </a>
                                </td>
                            </tr> -->

                            <tr v-for="(subCategory, index) in subCategories" :key="'sc'+index">
                                <td>{{(1+index)}}</td>
                                <td>{{ subCategory.name | upText }}</td>
                                <td>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" :id="'onOff'+index" :checked="subCategory.is_active"  @change="changeActiveStatus(subCategory)">
                                        <label class="custom-control-label" :for="'onOff'+index" ></label>
                                    </div>
                                </td>
                                <td>{{ subCategory.super_category != null ? subCategory.super_category :  'Deleted Category'}}</td>
                                <td>{{ subCategory.category_name != null ? subCategory.category_name :  'Deleted Category'}}</td>
                                <td> <img :src="getImageUrl(subCategory)" alt="" class="img img-responsive"></td>
                                <td>
                                    <button @click="editForm(subCategory)"  data-toggle="modal" data-target="#subCategoryNew" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button @click="deleteSubCategory(subCategory.id)" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <router-link :to="getSubCatLink(subCategory)" class="btn btn-success btn-sm"><i class="fa fa-cubes"></i></router-link>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div><!-- /.row -->


        <!-- Modal -->
        <div class="modal fade" id="subCategoryNew" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-subCategory"></i> {{ editMode ? 'Edit' : 'Add'}} Category-3</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form @submit.prevent="editMode ? updateSubCategory() : createSubCategory()">
                        <div class="modal-body">
                             <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Category-1</label>
                                <div class="col-sm-8">
                                    <select class="form-control" v-model="form.super_category_id" placeholder="Select Category" :class="{ 'is-invalid': form.errors.has('super_category_id') }" v-on:change="getCategory(this)">
                                        <option v-for="category of categories" :key="category.id" :value="category.id">{{category.name}}</option>
                                    </select>
                                    <has-error :form="form" field="category_id"></has-error>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-sm-4 col-form-label">Category-2</label>
                                <div class="col-sm-8">
                                    <select class="form-control" v-model="form.category_id" placeholder="Select Category" :class="{ 'is-invalid': form.errors.has('category_id') }">
                                        <option v-for="subCategory of supSubCategories" :key="subCategory.id" :value="subCategory.id" :selected="checkSelected(subCategory)" >{{subCategory.name}}</option>
                                    </select>
                                    <has-error :form="form" field="category_id"></has-error>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticEmail" class="col-sm-4 col-form-label">Category-3 Name</label>
                                <div class="col-sm-8">
                                    <input type="text"  class="form-control"  v-model="form.name" placeholder="Super SubCategory Name" :class="{ 'is-invalid': form.errors.has('name') }">
                                    <has-error :form="form" field="name"></has-error>
                                </div>
                            </div>
                           
                            <div class="form-group row">
                                <label for="staticEmail" class="col-sm-4 col-form-label">Category-3 Image</label>
                                <div class="col-sm-8">
                                    <input type="file" class="form-control" @change="fileSelected" id="staticEmail" :class="{ 'is-invalid': form.errors.has('image') }">
                                    <has-error :form="form" field="image"></has-error>
                                </div>
                            </div>
                            <div class="form-row" v-if="!editMode">
                                 <label for="staticEmail" class="col-sm-12 col-form-label">Add Category-4</label>
                                      <div class="form-group col-md-12">
                                        <div class="table-responsive">  
                                          <table class="table table-bordered" id="app" >
                                                <thead>
                                                    <tr>
                                                      <th class="col-xs-5">Category-4 Name <span class="text-danger"></span></th>
                                                      <th class="col-xs-1">
                                                          <div>
                                                              <button title="Add row" type="button" @click="addRow" class="btn btn-success btn-sm"><b>Add</b></button>
                                                          </div>
                                                      </th>
                                                    </tr>
                                                </thead> 
                                                <tbody>
                                                <tr v-for="(input, index) in inputs"> 
                                                    <td>
                                                      <input type="text" name="subcategory_name[]" class="form-control subcategory_name" placeholder="Category-4 Name">
                                                    </td>
                                                    <td>
                                                        <button title="Delete row" type="button" @click="deleteRow(index)" class="btn btn-danger btn-sm"><b><i class="fa fa-trash"></i></b></button>
                                                    </td>
                                                </tr>
                                               </tbody>
                                          </table>
                                        </div>
                                      </div>
                                    </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { moment } from 'moment';
    export default {
        data() {
            return {
                form : new Form({
                    id:'',
                    name:'',
                    image:'',
                    super_category_id : '',
                    category_id : '',
                    subcategory_name:[],
                    is_active: true
                }),
                subCategories: {},
                categories: {},
                supSubCategories:{},
                inputs: [],
                editMode: false
            }
        },
        methods :{
            createSubCategory(){
                this.$Progress.start();
                var subcategory_name = [];
                $(".subcategory_name").each(function(){ subcategory_name.push($(this).val())});
                this.form.subcategory_name=subcategory_name;

                this.form.post('api/subCategory').then( ()=>{
                    Fire.$emit('LoadSubCategory');
                    $('#subCategoryNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'SubCategory Created successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{

                    this.$Progress.fail();
                });

                // this.loadSubCategoryList();
            },
            updateSubCategory(){
                this.$Progress.start();
                this.form.put('api/subCategory/' + this.form.id).then( ()=>{
                    Fire.$emit('LoadSubCategory');
                    $('#subCategoryNew').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'SubCategory Updated successfully'
                    });

                    this.$Progress.finish();
                }).catch(()=>{
                    this.$Progress.fail();
                });
            },
            loadSubCategoryList() {
                axios.get("/api/subCategory").then( ({ data }) => (this.subCategories = data) );
            },
            checkSelected(subCategory){
                return subCategory.id == this.form.sub_Category_id
            },
            deleteSubCategory(id){
                // sweet alert modal
                swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        // send delete request
                        console.log(result)
                    if(result.value){
                        this.form.delete('/api/subCategory/'+id).then(() => {
                            swal.fire(
                            'Deleted!',
                            'Sub Category has been deleted.',
                            'success'
                            );
                            Fire.$emit('LoadSubCategory');
                        }).catch(()=>{
                            swal.fire(
                            'Failed!',
                            `Sub Category can't  be deleted.`,
                            'danger'
                            )
                        })
                    }
                })
            },
            addRow() {
              this.inputs.push({
                one: '',
                two: ''
              })
            },
            deleteRow(index) {
              this.form.subcategory_name.splice(index,1);
              this.inputs.splice(index,1);
            },
            newForm(){
                this.form.reset();
                this.editMode = false;
                this.supSubCategories = {};
                this.inputs= [];
            },
            editForm(data){
                this.form.reset();
                this.form.fill(data);
                this.getCategory();
                this.form.image= '';
                this.editMode = true;
                this.inputs= [];
            },
            loadCategoryList() {
                axios.get("api/category_all").then( ({ data }) => (this.categories = data) );
            },
            getCategory(){
                var cat_id = this.form.super_category_id;
                axios.get("api/sub_category_by_cat/"+cat_id).then(data=>{
                    console.log(data.data.sub_category);
                   this.supSubCategories = data.data.sub_category;
                }); 
                
            },
            getSubCatLink(subCategory){
                return `/subCategory/${subCategory.id}/cat`;
            },
            fileSelected(e){
                console.log('file slected', e);
                if(e.target.files.length > 0 ){
                    let file = e.target.files[0];
                    let reader= new FileReader();
                    reader.onloadend = () => {
                        // console.log('RESULT converted base 64');
                        this.form.image=  reader.result;
                    }
                    reader.readAsDataURL(file);
                }

            },
            changeActiveStatus(subCategory){
                console.log(subCategory);
                this.editForm(subCategory);
                this.form.is_active = !this.form.is_active ;
                this.updateSubCategory();
            },
            getImageUrl(subCategory){
                return subCategory.image  ? '/uploads/images/sub_category/' + subCategory.image : 'https://static.thenounproject.com/png/340719-200.png'  ;
            }
        },
        mounted() {
            console.log('Component mounted.')
        },
        created(){
            this.loadSubCategoryList();
            this.loadCategoryList();
            Fire.$on('LoadSubCategory', () => this.loadSubCategoryList() );
        }


    }
</script>

<style scoped>
img{
    max-width : 3vh;
    max-height : 3vh
}
</style>
