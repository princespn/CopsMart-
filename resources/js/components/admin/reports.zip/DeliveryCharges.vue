<template>
    <div class="container">
        <!-- /.row -->
        <div class="row">
            <h2>Delivery Charges List</h2>
        </div>
        <div class="row mt-3">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Delivery Charges List</h3>
                        <div class="card-tools">
                            <button type="button" @click="newForm" class="btn btn-success" data-toggle="modal" data-target="#DeliveryCharge"> <i class="fa fa-slab-plus"></i> Add New</button>
                        </div>
                    </div>
                    
                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Sr. No.</th>
                                    <th>Start Limit</th>
                                    <th>End Limit</th>
                                    <th>Delivery Charge</th>
                                    <th>Extra Charges Per/km</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tr v-for="(deliveryCharges, index) in deliveryCharges" :key="'sc'+index">
                                <td>{{(1+index)}}</td>
                                <td>{{ deliveryCharges.start_limit }}</td>
                                <td>{{ deliveryCharges.end_limit }}</td>
                                <td>{{ deliveryCharges.delivery_charge }}</td>
                                <td>{{ deliveryCharges.extra_charges_per_km }}</td>
                                <td>
                                    <button @click="editForm(deliveryCharges)"  data-toggle="modal" data-target="#DeliveryCharge" class="btn btn-primary btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </button>
                                    <button @click="deleteDeliveryCharge(deliveryCharges.id)" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </td>
                            </tr>

                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
        </div><!-- /.row -->


        <!-- Modal -->
        <div class="modal fade" id="DeliveryCharge" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLongTitle"><i class="fa fa-slab"></i> {{ editMode ? 'Edit' : 'Add'}} Marketing Box</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form @submit.prevent="editMode ? updateDeliveryCharge() : createDeliveryCharge()">
                        <div class="modal-body">
                            <div class="form-group row">
                                <label for="staticEmail" class="col-sm-3 col-form-label"> Start Limit</label>
                                <div class="col-sm-9">
                                    <input type="charges" min="0" class="form-control"  v-model="form.start_limit" placeholder="Start Limit" :class="{ 'is-invalid': form.errors.has('start_limit') }">
                                    <has-error :form="form" field="start_limit"></has-error>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="staticEmail" class="col-sm-3 col-form-label"> End Limit</label>
                                <div class="col-sm-9">
                                    <input type="charges" min="0" class="form-control"  v-model="form.end_limit" placeholder="End Limit" :class="{ 'is-invalid': form.errors.has('end_limit') }">
                                    <has-error :form="form" field="end_limit"></has-error>
                                </div>
                            </div>
                             <div class="form-group row">
                                <label for="staticEmail" class="col-sm-3 col-form-label"> Delivery Charge</label>
                                <div class="col-sm-9">
                                    <input type="charges" min="0" class="form-control"  v-model="form.delivery_charge" placeholder="Delivery Charge" :class="{ 'is-invalid': form.errors.has('delivery_charge') }">
                                    <has-error :form="form" field="delivery_charge"></has-error>
                                </div>
                            </div>
                             <div class="form-group row">
                                <label for="staticEmail" class="col-sm-3 col-form-label"> Extra Charges Per/km</label>
                                <div class="col-sm-9">
                                    <input type="charges" min="0" class="form-control"  v-model="form.extra_charges_per_km" placeholder="Extra Charges Per/km" :class="{ 'is-invalid': form.errors.has('extra_charges_per_km') }">
                                    <has-error :form="form" field="extra_charges_per_km"></has-error>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import { moment } from 'moment';
    import vSelect from 'vue-select';
    import "vue-select/dist/vue-select.css";
    export default {
        components:{
            'v-select': vSelect,
        },
        data() {
            return {
                form : new Form({
                    id:'',
                    start_limit :null,
                    end_limit :null,
                    delivery_charge :null,
                    extra_charges_per_km :null,
                    
                }),
                errors:{},
                deliveryCharges: {},
                editMode: false,
            }
        },
        methods :{
            createDeliveryCharge(){
                this.$Progress.start();
                this.form.post('/api/delivery_charges').then( ()=>{
                    this.loadDeliveryChargeList();
                    $('#DeliveryCharge').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'Delivery Charge added successfully'
                    });
                    this.$Progress.finish();
                }).catch(()=>{

                    this.$Progress.fail();
                });
            },
            updateDeliveryCharge(){
                this.$Progress.start();
                
                this.form.put('/api/delivery_charges/' + this.form.id).then( ()=>{
                    this.loadDeliveryChargeList();
                    $('#DeliveryCharge').modal('hide');
                    toast.fire({
                        type: 'success',
                        title: 'Delivery Charge Updated successfully'
                    });
                    this.$Progress.finish();
                }).catch(()=>{
                    this.errors =data.response.data.errors;
                    this.$Progress.fail();
                });
            },
            loadDeliveryChargeList() {
                
                axios.get('/api/delivery_charges').then( ({ data }) => (this.marketingbox = data) );
            },
            deleteDeliveryCharge(id){
                // sweet alert modal
                swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        // send delete request
                        console.log(result)
                    if(result.value){
                        this.form.delete('/api/delivery_charges/'+id).then(() => {
                            swal.fire(
                            'Deleted!',
                            'Delivery Charge has been deleted.',
                            'success'
                            );
                            this.loadDeliveryChargeList();
                        }).catch(()=>{
                            swal.fire(
                            'Failed!',
                            'Delivery Charge can not  be deleted.',
                            'danger'
                            )
                            this.loadDeliveryChargeList();
                        })
                    }
                })
            },
            newForm(){
                this.form.reset();
                this.editMode = false;
            },
            editForm(data){
                this.selected = [];
                this.form.reset();
                this.form.fill(data);
                this.editMode = true;
            },
            loadDeliveryChargeList() {
                axios.get("/api/delivery_charges").then( ({ data }) => (this.deliveryCharges = data) );
            },
        },
        mounted() {
            console.log('Component mounted.');
            this.loadDeliveryChargeList();
        }
    }
</script>

<style scoped>
img{
    max-width : 3vh;
    max-height : 3vh
}
</style>
